import sys,json
for line in sys.stdin:
 try:
  req=json.loads(line);m=req.get('method');i=req.get('id')
  if i is None:continue
  if m=='initialize':result={'protocolVersion':'2024-11-05','capabilities':{'tools':{}},'serverInfo':{'name':'luna-qa','version':'1'}}
  elif m=='tools/list':result={'tools':[{'name':'echo','description':'Echo a test marker without side effects','inputSchema':{'type':'object','properties':{'text':{'type':'string'}},'required':['text']}}]}
  elif m=='tools/call':result={'content':[{'type':'text','text':'MCP_ECHO:'+req['params']['arguments']['text']}]}
  elif m=='resources/list':result={'resources':[]}
  elif m=='prompts/list':result={'prompts':[]}
  elif m=='ping':result={}
  else:
   print(json.dumps({'jsonrpc':'2.0','id':i,'error':{'code':-32601,'message':'unsupported'}}),flush=True);continue
  print(json.dumps({'jsonrpc':'2.0','id':i,'result':result}),flush=True)
 except Exception as e: print(str(e),file=sys.stderr,flush=True)
