import { appendFileSync, readFileSync } from 'node:fs';
const dir = process.env.TEST_RUN!;
const key = readFileSync(dir + '/credential', 'utf8').trim();
const audit = (record: unknown) => appendFileSync(dir + '/evidence/provider-audit.jsonl', JSON.stringify({at:new Date().toISOString(),...record as object})+'\n');
const server = Bun.serve({hostname:'127.0.0.1',port:18741,idleTimeout:255,async fetch(req) {
 const url = new URL(req.url);
 if(url.pathname === '/health') return Response.json({ok:true,model:'gpt-5.6-luna'});
 if(url.pathname.endsWith('/models')) return Response.json({object:'list',data:[{id:'gpt-5.6-luna',object:'model'}]});
 const text = await req.text();
 let body; try {body=JSON.parse(text)} catch {return new Response('JSON required',{status:400})}
 if(body.model !== 'gpt-5.6-luna') {audit({event:'blocked_model',model:body.model,path:url.pathname});return new Response('Only gpt-5.6-luna authorized',{status:403});}
 const id=crypto.randomUUID();audit({event:'request',id,model:body.model,path:url.pathname,tools:(body.tools??[]).map((t:any)=>t.name??t.function?.name),reasoning:body.reasoning});
 audit({event:'input_shape',id,inputContentTypes:(body.input??[]).flatMap((x:any)=>Array.isArray(x.content)?x.content.map((c:any)=>c.type):[typeof x.content]),imageCount:(text.match(/"type":"input_image"/g)??[]).length});
 try {
 const upstream=await fetch('https://api.12th.day'+url.pathname,{method:req.method,headers:{'authorization':'Bearer '+key,'content-type':'application/json','accept':'text/event-stream'},body:text,signal:AbortSignal.timeout(240000)});
 audit({event:'response',id,status:upstream.status});
 const headers=new Headers();headers.set('content-type',upstream.headers.get('content-type')??'application/json');
 return new Response(upstream.body,{status:upstream.status,headers});
 } catch(e) {audit({event:'error',id,error:String(e)});return new Response(String(e),{status:502})}
}}); console.log('Luna-only gateway ready '+server.url);
